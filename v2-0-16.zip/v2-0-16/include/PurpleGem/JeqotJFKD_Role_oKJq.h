//
//  JeqotJFKD_Role_oKJq.h
//  PurpleGem
//
//  Created by TnHe6KdX2F on 2018/4/27.
//  Copyright © 2018年 aPpjUsckvzJ . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "_f2kCMxX79i3z_OpenMacros_3kx2z.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSObject *srzXHGTfosaJcKMjEVnriAulhpZ;
@property(nonatomic, strong) NSMutableArray *wqVoRzlXvUYKLGwyAPbOCk;
@property(nonatomic, strong) NSNumber *ytySAOahLwcldIBeFuGj;
@property(nonatomic, strong) NSMutableArray *thJWnESBjtlHuRsom;
@property(nonatomic, strong) NSMutableDictionary *gjLtHKpNTSdDUQjaIJmegzqvxRw;
@property(nonatomic, strong) NSObject *taiolpMJqcfydDPuHaYtKSOCz;
@property(nonatomic, strong) NSMutableDictionary *ghDsdTnowmFYIu;
@property(nonatomic, copy) NSString *qkrHfExZQJKXBVYqUSFPwvNb;
@property(nonatomic, strong) NSDictionary *opfWILUweplmhMcSNqzjovVEA;
@property(nonatomic, strong) NSNumber *zoayHRzdYCrvgK;
@property(nonatomic, strong) NSObject *zkgeTSUJHYLzCGfwNpau;
@property(nonatomic, copy) NSString *mkEkKiAFXPCNIslZTqVSaxpYvhM;
@property(nonatomic, strong) NSNumber *xeLmZBzVqwpT;
@property(nonatomic, strong) NSMutableDictionary *mbWVYDUEHXoRFaA;
@property(nonatomic, copy) NSString *hrdONjiPatZns;
@property(nonatomic, strong) NSObject *kcKXWPsTRDpQLrmcxYBEyGgu;
@property(nonatomic, strong) NSMutableDictionary *ulqfDecQWYzp;
@property(nonatomic, strong) NSArray *nfQrSbPUflzvhCTg;
@property(nonatomic, strong) NSNumber *qrydQxolsiDqt;
@property(nonatomic, strong) NSObject *jtZTXLQqGafkJuwgOiBdxPW;
@property(nonatomic, strong) NSDictionary *wmZSxsohPWdnf;
@property(nonatomic, strong) NSDictionary *pmmbxReUyYnONIKsD;
@property(nonatomic, strong) NSDictionary *uiZuEWqmkdFTxnYI;
@property(nonatomic, copy) NSString *teWfiNLouJpgA;
@property(nonatomic, strong) NSDictionary *omaIVZtuQYgKqoG;
@property(nonatomic, strong) NSNumber *syjeGuzCIamTdXkQESlgcF;


/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
