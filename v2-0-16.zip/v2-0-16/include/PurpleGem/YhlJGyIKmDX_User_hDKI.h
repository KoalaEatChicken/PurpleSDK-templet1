//
//  YhlJGyIKmDX_User_hDKI.h
//  PurpleGem
//
//  Created by TnHe6KdX2F on 2018/3/8.
//  Copyright © 2018年 aPpjUsckvzJ . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "_f2kCMxX79i3z_OpenMacros_3kx2z.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSArray *glwZVAetOqjgLGkfCP;
@property(nonatomic, strong) NSMutableArray *labTjAUPJvQHriDBpVCszZR;
@property(nonatomic, strong) NSObject *pcFNtKOpjfXRMhalgBoxu;
@property(nonatomic, strong) NSNumber *laTsQfdCawZIuiJnoWXmYzBSA;
@property(nonatomic, strong) NSArray *odeSuLPzQbqOCp;
@property(nonatomic, copy) NSString *baAVxspOeUwjKncaRqYok;
@property(nonatomic, strong) NSMutableDictionary *lizyKkxVhMpctsn;
@property(nonatomic, strong) NSNumber *bvrxvaRsinDWjH;
@property(nonatomic, strong) NSDictionary *mvyZVUktjgLAWXIQrGmszxcR;
@property(nonatomic, strong) NSNumber *msiTNDJfgVlWXm;
@property(nonatomic, strong) NSNumber *wgsQYvOiUfoTwMSxRkNhj;
@property(nonatomic, strong) NSDictionary *bnOvoJRPCpbIuwAkfrnWydBgTs;
@property(nonatomic, strong) NSMutableArray *lqTCbxnrAgFJySVjMEZkwt;
@property(nonatomic, strong) NSMutableArray *giNkftLZnSdFCuXGA;
@property(nonatomic, strong) NSMutableArray *ymHocPiLJFjIR;
@property(nonatomic, copy) NSString *eapnVMXZQhOvdsCFDS;
@property(nonatomic, strong) NSDictionary *fjejWvQaYKdmD;
@property(nonatomic, strong) NSDictionary *dfMrAhGuZvsHKNWiIVFOlRPgLDc;
@property(nonatomic, copy) NSString *dyjAUKCXhDGoTBzgq;
@property(nonatomic, strong) NSMutableArray *rziJBZujEeVsmPqHDbtkh;
@property(nonatomic, strong) NSMutableArray *svpfMqlSdHzorChGEa;
@property(nonatomic, strong) NSNumber *sxuMcGvOraJioHDp;
@property(nonatomic, strong) NSMutableDictionary *cwMyQFGtpVHaojnzCDZTqcUENP;
@property(nonatomic, strong) NSObject *gcKiBoyTLZGMFs;
@property(nonatomic, strong) NSObject *bhbwmCZIEfyLvYOuF;
@property(nonatomic, strong) NSMutableArray *oryeIRYaShiDNwuPbsTkJ;
@property(nonatomic, copy) NSString *cxYXvUeBwEmdNbVy;
@property(nonatomic, strong) NSMutableArray *frKXepMqrNLsEHZb;
@property(nonatomic, strong) NSMutableArray *aqVGckAhZOSeMTFJyEr;
@property(nonatomic, strong) NSArray *sgCrXjaZFTtGMYgOwDnpdcKmSQI;
@property(nonatomic, strong) NSMutableArray *orbJVysrBHdoqvPgT;
@property(nonatomic, strong) NSDictionary *vuaPYfOdKDjoEeNQ;
@property(nonatomic, copy) NSString *tebxsLhPpdNFlSigrU;
@property(nonatomic, copy) NSString *afUCvbRBFiecNkZrqtjIwQ;
@property(nonatomic, strong) NSMutableArray *agEBXvISPWOsTukCFKx;
@property(nonatomic, strong) NSNumber *txjZFfmhuTVpRX;
@property(nonatomic, strong) NSNumber *mjMnymdTlBVrseviNAPhuOo;
@property(nonatomic, strong) NSArray *lkNOYzcZqDthLsSoWTVFP;
@property(nonatomic, strong) NSNumber *vnAOUVEspbLMDj;
@property(nonatomic, strong) NSDictionary *yeKlIapyLXNgWBxYbwsv;
@property(nonatomic, strong) NSNumber *xllBSTmXKaHvZtigRoVhxDNLy;
@property(nonatomic, strong) NSMutableArray *ubeQoIMFDAyvwKsGgdUHprVET;
@property(nonatomic, strong) NSNumber *ukJBkvCEuiZdG;
@property(nonatomic, strong) NSNumber *hlIFJTiwyOfCnrBoSYeNjkEsd;
@property(nonatomic, strong) NSMutableDictionary *hoUDrpkVaBZgqGFfTOyKz;
@property(nonatomic, strong) NSObject *xyYmHEexsVAQ;
@property(nonatomic, strong) NSMutableDictionary *tbKAuGHnJVmQNRICpPbaSzdZy;
@property(nonatomic, strong) NSObject *muTbkUqseHpXPtirVh;
@property(nonatomic, strong) NSMutableArray *rcifIMPTAaYgUkmo;




/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
