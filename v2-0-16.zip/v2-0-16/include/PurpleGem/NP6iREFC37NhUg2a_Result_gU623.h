//
//  NP6iREFC37NhUg2a_Result_gU623.h
//  PurpleGem
//
//  Created by TnHe6KdX2F on 2018/3/5.
//  Copyright © 2018年 aPpjUsckvzJ . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "_f2kCMxX79i3z_OpenMacros_3kx2z.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSObject *jrEAcWgPyYsoQTnaIGOd;
@property(nonatomic, strong) NSMutableDictionary *hcCfWiXBvLeTrconVM;
@property(nonatomic, strong) NSObject *zrNhgZOVGcHPDeJtqXIyviMolQw;
@property(nonatomic, strong) NSArray *tvHNtKzpnqVvWfkBrsa;
@property(nonatomic, strong) NSNumber *kvnsHpLXivNYyePthOo;
@property(nonatomic, strong) NSDictionary *ygBCZDdulVTRsKvFrobMJzgjU;
@property(nonatomic, strong) NSMutableArray *gmiFynOtAlqKafzvUu;
@property(nonatomic, strong) NSArray *wpOpeYVLRvUkNCBGTiKcbufFgXs;
@property(nonatomic, strong) NSObject *nyAgrKkBXqOZhtbFR;
@property(nonatomic, strong) NSMutableArray *kcnMsvFOYWNXoyQEgHmTSRpPr;
@property(nonatomic, strong) NSMutableDictionary *jrhgSYRdloKjUTfOXNmBHWEZDQ;
@property(nonatomic, strong) NSDictionary *gdeSXUjGuYDER;
@property(nonatomic, strong) NSNumber *naEVSdruYLeWFZkmARHDT;
@property(nonatomic, strong) NSMutableArray *oubUeQIVEsugTyfzaqwcDxRr;
@property(nonatomic, strong) NSMutableDictionary *hshqjCAzaWUSDfvBKrRHm;
@property(nonatomic, strong) NSDictionary *dmdipsqFMwuvRD;
@property(nonatomic, strong) NSObject *ylFruzGcsXSVkoIPTdRAHNmL;
@property(nonatomic, strong) NSDictionary *cnQmHYROFPnx;
@property(nonatomic, strong) NSObject *zcboVCIEstHMGmLdXqAizWYUpw;
@property(nonatomic, strong) NSObject *vhuLxtNvQMOTcJFrEyVjRa;
@property(nonatomic, strong) NSMutableDictionary *noCNcMwVeyOlXrQWzpuEIbd;
@property(nonatomic, strong) NSMutableArray *ufegHyLUPdCshWAcIOvXEV;
@property(nonatomic, copy) NSString *fdOxBDwCmREjbasieUqtH;
@property(nonatomic, strong) NSMutableArray *blvXmZbEnMPkcgey;
@property(nonatomic, strong) NSNumber *jzuEjwyDQpISZ;
@property(nonatomic, strong) NSArray *hyaFJyVNzbZBcYiQtXCe;
@property(nonatomic, strong) NSArray *dePGCJuEYKRh;
@property(nonatomic, strong) NSObject *zwRkJSWCgdfI;
@property(nonatomic, copy) NSString *rsOmKgBqEvCbdMQwFpNAhXnVSl;
@property(nonatomic, strong) NSMutableDictionary *rtpzZQsOcNKreTuILVjbEP;
@property(nonatomic, strong) NSMutableDictionary *xtaLFigVRxtEKmjvYHwkWBCXr;
@property(nonatomic, strong) NSObject *tfGYkFaoKABECSrLcyeQWJsnR;
@property(nonatomic, strong) NSMutableArray *fpkYRtQLKbDnCsgoEGwTAUOlXda;
@property(nonatomic, strong) NSNumber *uxadhjRrUtWkeBoCNGmzp;
@property(nonatomic, copy) NSString *yeNlSOGpUHngZoBf;
@property(nonatomic, copy) NSString *wxiWTwSoeabODuP;
@property(nonatomic, strong) NSArray *xtTuaSlcjFDdCpIJMybvQihfgUO;
@property(nonatomic, strong) NSMutableArray *mzYPWIAZiksuhbrgonc;
@property(nonatomic, copy) NSString *bjnhWLfVSFwJjrCTGpOaHzMkQ;
@property(nonatomic, strong) NSDictionary *aprPREBOXsiauzHenQATpSGMfvw;
@property(nonatomic, strong) NSMutableArray *fqsPSqobwQOhJTylW;
@property(nonatomic, strong) NSObject *yvPhyMmRiYVKQqGJgf;
@property(nonatomic, strong) NSObject *nsmNwejnuFsDE;
@property(nonatomic, copy) NSString *kmjpIJqtkgvxBYFdAfozCDwW;




/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
