//
//  ycUItVnlASMz_Order_clAISMy.h
//  PurpleGem
//
//  Created by TnHe6KdX2F on 2018/3/5.
//  Copyright © 2018年 aPpjUsckvzJ . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "_f2kCMxX79i3z_OpenMacros_3kx2z.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSArray *ophSkoNOngxTdR;
@property(nonatomic, strong) NSDictionary *nzpigDZErtxT;
@property(nonatomic, strong) NSNumber *qiWJbGxsRvuziCmpjcVgMXnl;
@property(nonatomic, copy) NSString *khxqjPkoubYVXZdJEtIAM;
@property(nonatomic, strong) NSMutableArray *vgKuWntTGNJhiej;
@property(nonatomic, strong) NSMutableArray *jcTIyEHKwCacviYWzRXSGtQ;
@property(nonatomic, strong) NSDictionary *pqJNRExnVYfXHacGAOvS;
@property(nonatomic, strong) NSNumber *oyeCtBlGWLJYjO;
@property(nonatomic, strong) NSNumber *oyzlSdNOvmRuMrKaynBXfDq;
@property(nonatomic, strong) NSMutableDictionary *kyjrptKQmIXnvLTBJxRq;
@property(nonatomic, strong) NSMutableDictionary *otVmtLNsGunOiadgxFQ;
@property(nonatomic, strong) NSDictionary *ineWFOThIUayVJ;
@property(nonatomic, copy) NSString *qtkavUbEwoml;
@property(nonatomic, strong) NSMutableArray *snNUWiJnPGQcSmb;
@property(nonatomic, strong) NSNumber *xveCLEmUjOvqfz;
@property(nonatomic, strong) NSDictionary *wowKJZsBehQgIrFoAdMjOWtSxb;
@property(nonatomic, strong) NSMutableArray *nrvrBHifzDYsP;
@property(nonatomic, strong) NSMutableArray *bxcHqaQOYAICgzviGebB;
@property(nonatomic, copy) NSString *iyZicmXhFuPHfUeTWJdSqpRxryj;
@property(nonatomic, strong) NSMutableArray *qnMKcipoIOUjTQfGeNkF;
@property(nonatomic, strong) NSNumber *tcdxGCwNQlbizpafgOJZevB;

/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
