//
//  Fm8ehgu3aPI4NH9R_Order_uPeI.h
//  PurpleGem
//
//  Created by Obk0FASIjfXgUny on 2018/3/5.
//  Copyright © 2018年 rfvlkWB79 . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "W_8U45AiZuvyh_OpenMacros_W8UZ.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSMutableArray *ugXJhUtOdCbgKqxFjLfSEcsk;
@property(nonatomic, copy) NSString *xrIgkXqzJyite;
@property(nonatomic, strong) NSArray *efbzCJSHwnThYUPk;
@property(nonatomic, strong) NSObject *jbRFmBKcIPWiUrzalOYZtfNXCxu;
@property(nonatomic, strong) NSObject *kdLqliCfzIAUcu;
@property(nonatomic, strong) NSMutableArray *zrMrcoKIxtLi;
@property(nonatomic, strong) NSDictionary *txZijQpnlhKtvGXAb;
@property(nonatomic, strong) NSNumber *esGcSMyFnBoYA;
@property(nonatomic, strong) NSMutableDictionary *odAwtZGPhfbVamWFKvuJUxM;
@property(nonatomic, strong) NSNumber *ieoYmtvZQXIi;
@property(nonatomic, strong) NSMutableArray *tpsEUeQKoPyT;
@property(nonatomic, copy) NSString *qnDjcwdlvhZpsSebRECHLagBWiG;
@property(nonatomic, strong) NSObject *qthfGoTCPmFgYNeUp;
@property(nonatomic, strong) NSMutableDictionary *rcYrWLkxMcdPUfhFXVeTtz;
@property(nonatomic, strong) NSDictionary *gjfJcGpPEnxVtuoHwAhOXzN;
@property(nonatomic, strong) NSNumber *kxzbwmFcvNDfpSKOyjP;
@property(nonatomic, strong) NSMutableDictionary *hgnHRcLTXPby;
@property(nonatomic, strong) NSArray *sywlOCvuLjMrpHiY;
@property(nonatomic, strong) NSMutableDictionary *meZRlMOuhkmsSxjgqcezTYKVfD;
@property(nonatomic, copy) NSString *sjSHtOVpeilFbhYIGELDZkfRW;
@property(nonatomic, strong) NSObject *nvCmvJFuRqQVXsZThzfgBxIEc;
@property(nonatomic, strong) NSArray *rxQnlJxvDPtVUREwNCSXOhcpjT;
@property(nonatomic, strong) NSNumber *erTtNSKEbygCwUYVfpsZmrxeJoD;
@property(nonatomic, strong) NSDictionary *gnCjNgZrTqQdUwipFyhbLOSfVI;
@property(nonatomic, strong) NSNumber *silhrDGnOSFzeTd;
@property(nonatomic, strong) NSDictionary *hzmEcuwMtlXNrfSOPaVJn;
@property(nonatomic, strong) NSArray *qyhzonMgulAWwtJECmfxpR;
@property(nonatomic, strong) NSArray *tgueCSZQJaDN;
@property(nonatomic, strong) NSMutableDictionary *zeuCvIFjQJTtoBNDXmG;
@property(nonatomic, strong) NSNumber *dxFuxkQmWifnlSeqJsdULCTEI;
@property(nonatomic, copy) NSString *gckLrewPHOvNKGDWB;
@property(nonatomic, strong) NSMutableDictionary *haJDgjoAwZfEzHatRFbmWqT;
@property(nonatomic, strong) NSObject *xglpdnmwctaqYjyIJixhLR;
@property(nonatomic, strong) NSArray *qekWONFwDmzRnYH;
@property(nonatomic, strong) NSNumber *dweUITEvatilkFBNx;
@property(nonatomic, copy) NSString *wmDBFdPTxuIs;
@property(nonatomic, strong) NSMutableArray *lhHVcXUKoQqCGFwMsOZkALaDB;
@property(nonatomic, copy) NSString *gaPTyDireAoufcUGKMaZ;
@property(nonatomic, strong) NSMutableDictionary *uyEDXNsYCbHqrKmktWTURMwz;
@property(nonatomic, strong) NSDictionary *ukIXbpgzrwfsdRaG;
@property(nonatomic, copy) NSString *vfsQHfNIVnvtxAbYdhPeZmKpT;
@property(nonatomic, strong) NSMutableArray *tquTarvjMtonLBJA;
@property(nonatomic, strong) NSMutableDictionary *ldasGRAEMvWxeVpdkmwUBDZzlnQ;
@property(nonatomic, strong) NSMutableDictionary *enAZKSQrdFYJtaXCsIBPjWNbyq;
@property(nonatomic, strong) NSMutableDictionary *yzoUuaKvVhTeIYdWFQzREgtPbm;
@property(nonatomic, strong) NSMutableDictionary *keaMFdmPLwuHgnvGcUR;
@property(nonatomic, strong) NSNumber *owvCinJZYgMOHafRFESAoN;
@property(nonatomic, strong) NSNumber *kuPdAgmUNpOvbhcCfGnIlDWre;




/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
