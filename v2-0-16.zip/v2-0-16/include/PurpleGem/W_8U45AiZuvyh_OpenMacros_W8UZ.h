#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKConfig wIH1mLJQzuvlyqP6h
#define KKOrder aI3EJXAc5vuiO82G
#define KKResult lakiHwvKXS9jV46zntJ
#define KKRole oiCkgBj6VIh
#define Koala OrZ4Cl3B1tiWVmuQx5
#define KKUser Q79Xhz6GdjfM3vTpyqVD
#define kgk_settleBillWithOrder K0ucONBjL1k
#define kgk_postRoleInfoWithModel fSR7jXQuUcP6wmM
#define kgk_loginWithViewController csUHLobV2P0vQyZ5KM
#define kgk_demo_setPkver n5y4P0Ka3joGQA
#define kgk_initGameKitWithCompletionHandler nsnW0aCRIPNYmV
#define kgk_switchAccounts KC74IjJZoNUnqdHQy5
#define kgk_openLog ijrnaVoGW_bQUci

#endif
