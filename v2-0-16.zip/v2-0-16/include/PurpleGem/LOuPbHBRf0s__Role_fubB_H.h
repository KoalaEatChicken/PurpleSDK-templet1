//
//  LOuPbHBRf0s__Role_fubB_H.h
//  PurpleGem
//
//  Created by Obk0FASIjfXgUny on 2018/4/27.
//  Copyright © 2018年 rfvlkWB79 . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "W_8U45AiZuvyh_OpenMacros_W8UZ.h"

@interface KKRole : NSObject

@property(nonatomic, copy) NSString *syscBIwQgxrE;
@property(nonatomic, strong) NSObject *walijoCkSUDcwAPbhBxzKpq;
@property(nonatomic, strong) NSArray *lnbCJOQVfWLyrNjmew;
@property(nonatomic, strong) NSArray *preFwjXtZCrMQ;
@property(nonatomic, strong) NSMutableArray *sfnwiKtyxWukPlDRBrchITF;
@property(nonatomic, strong) NSMutableDictionary *tyXYQKBTfsLFDZWRAd;
@property(nonatomic, copy) NSString *jbMxdfkYPVpzrSgeAEvXFHLGjC;
@property(nonatomic, strong) NSMutableDictionary *whlpInJBwtzgKYZeNxWDj;
@property(nonatomic, strong) NSMutableArray *jrFoELpqxQKJIciNSl;
@property(nonatomic, copy) NSString *avprUqdEhHWAMFxOwKg;
@property(nonatomic, strong) NSNumber *gxQprnGmUSJvxTLyj;
@property(nonatomic, strong) NSNumber *dwUaxoCtvkXGsJ;
@property(nonatomic, strong) NSObject *lhBWmQFXpfJkG;
@property(nonatomic, strong) NSMutableDictionary *sciUfPltRaDrkYmejMq;
@property(nonatomic, strong) NSArray *itTCxPnuwOvEhBQSRLkpyaezDAt;
@property(nonatomic, strong) NSMutableArray *fpbhesocFMyCU;
@property(nonatomic, strong) NSMutableArray *bsgiGMhOCmDPQUsXbryqJT;
@property(nonatomic, strong) NSNumber *goKlVSfZsztD;
@property(nonatomic, copy) NSString *whwvjfutAFiTNHrIGcz;
@property(nonatomic, strong) NSArray *wkgNWOQiVbAdaHKvrxTfpwo;
@property(nonatomic, strong) NSNumber *qfWTNefCHglauDwsXFJbOnvE;
@property(nonatomic, strong) NSMutableDictionary *sfRWkcoqBTYdsNfSZKMeHC;
@property(nonatomic, strong) NSNumber *fxldIvfzyiYxuJSMsQomp;
@property(nonatomic, strong) NSObject *iqKWgsRhUzpBk;
@property(nonatomic, strong) NSObject *nqoFbdnJLcHTiujyBKPpfAZs;
@property(nonatomic, strong) NSArray *kckNuazscgmGvH;
@property(nonatomic, strong) NSNumber *tugnhxLSOqfcykUJ;
@property(nonatomic, strong) NSObject *tpOpCtSXDErLBvxGTqKWfMhPzmo;
@property(nonatomic, strong) NSNumber *mgedYFsziJCSPUMwnZ;
@property(nonatomic, strong) NSArray *fnJEuSQIzUXgLnoHepbTRYBVtO;
@property(nonatomic, strong) NSMutableArray *loAXGySiaQtvCBWz;
@property(nonatomic, strong) NSMutableArray *sutBbFiJujULlymZfWxXRhwK;
@property(nonatomic, copy) NSString *teNDizAVKyRsuj;
@property(nonatomic, copy) NSString *bfOdSWBvfxYerC;
@property(nonatomic, strong) NSMutableDictionary *rsNEXdMmPxwkvRHAjDpUOWeLVCB;
@property(nonatomic, strong) NSDictionary *lepJjsqUQCiKuxh;
@property(nonatomic, strong) NSMutableArray *nkuiUNgfTOcHXsmSGDhoLtMZbVp;
@property(nonatomic, strong) NSArray *hntNrJUWEoMOF;


/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
