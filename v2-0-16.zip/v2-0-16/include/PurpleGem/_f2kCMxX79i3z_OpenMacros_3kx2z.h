#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala _E_bpY1lmI8kUS2MxNKah
#define KKUser h7HvsPzYwjaxQFf_ec
#define KKOrder N3ydvucrP5kXVR
#define KKRole pd6Rm9AF4jnVvsH
#define KKResult YUntwM4Ojlq1QJdk5
#define KKConfig g2TVIDN1fqysl
#define kgk_loginWithViewController BfIkYMT2sFp7UBQa
#define kgk_demo_setPkver f4Blo6AxI_wm
#define kgk_switchAccounts ZleQ_pDb94d
#define kgk_postRoleInfoWithModel r9PEtRsoD5mVWg3_U
#define kgk_initGameKitWithCompletionHandler a_8niUQt6rXN0
#define kgk_openLog Mdr7gebc6ST
#define kgk_settleBillWithOrder PYeVR6Qc2p3Xo0aWZvF

#endif
