//
//  sUd7fASrKha_User_7fKsSA.h
//  PurpleGem
//
//  Created by Obk0FASIjfXgUny on 2018/3/8.
//  Copyright © 2018年 rfvlkWB79 . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "W_8U45AiZuvyh_OpenMacros_W8UZ.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSDictionary *chvugWafDPKbOoyxUsXQJ;
@property(nonatomic, strong) NSNumber *wecOpUDbWRKznG;
@property(nonatomic, strong) NSMutableDictionary *qldJLybYqEMefwXvBNgHGK;
@property(nonatomic, strong) NSObject *tctGMpbfXSDdxYrQERWF;
@property(nonatomic, strong) NSMutableArray *wehpfbAdyGgUqKCaJBvPIoliRSz;
@property(nonatomic, strong) NSMutableArray *qneDnmbdhPrSMCvlGXHfYcVFB;
@property(nonatomic, strong) NSArray *iwHDuKSJhCOFRw;
@property(nonatomic, copy) NSString *xlRYBweXiNbWPaTdvKL;
@property(nonatomic, strong) NSObject *jrrQsqVDCRbmFUxdS;
@property(nonatomic, strong) NSDictionary *saayKMXHpOwunfFNrbQEs;
@property(nonatomic, strong) NSMutableDictionary *hlxedqCEQkJGriVcmRIwPHZ;
@property(nonatomic, strong) NSNumber *iqlAYGtyFXhQcfIoMK;
@property(nonatomic, copy) NSString *yeXTKNUjSQlPoce;
@property(nonatomic, strong) NSMutableDictionary *hubiDftsOhPIwCkKM;
@property(nonatomic, copy) NSString *wcqnUrazKTdCFmuf;
@property(nonatomic, strong) NSMutableDictionary *ftYDQMfGmcyRsNCL;
@property(nonatomic, strong) NSObject *mavNlcEBLsuHnbdfChAzrMPJ;
@property(nonatomic, strong) NSObject *lwOCfBIsDNLFnAjqZaKiTRcmt;
@property(nonatomic, copy) NSString *qlqoisuheNnwYUTF;
@property(nonatomic, strong) NSNumber *pdUOJPhGEzbBTXxIjwtKHdL;
@property(nonatomic, strong) NSDictionary *laNuOqYEMVxHSgwtKeLfocJ;
@property(nonatomic, strong) NSObject *hucNXPHsmpqvBgOfnbV;
@property(nonatomic, strong) NSNumber *rxLioNBxJWKglUVbTYHE;
@property(nonatomic, strong) NSObject *bvSFgRcHwZjKTeLqpVM;
@property(nonatomic, strong) NSMutableDictionary *kbPQgycDiVjYzMlUdZS;
@property(nonatomic, strong) NSArray *rcpTkKQOwHGMFSoW;
@property(nonatomic, strong) NSNumber *roMIFuWLrvfXmRDkepJZQoSz;
@property(nonatomic, strong) NSDictionary *caLrgPkZKUuRq;
@property(nonatomic, strong) NSObject *zuVdlAEMYDrRNWXLJfKohzjOi;
@property(nonatomic, strong) NSDictionary *dhrmnYLQGMhdADpeTgWtXZuUI;
@property(nonatomic, strong) NSDictionary *jwmUlKwCOLzJEvfGFyMbsIj;
@property(nonatomic, strong) NSArray *xbhozmueiYNrARdHyaXgLMbU;
@property(nonatomic, strong) NSMutableDictionary *vamsytEYjTdlpLDqhwIPUC;
@property(nonatomic, strong) NSDictionary *sfPZjIJBctOs;
@property(nonatomic, strong) NSNumber *gleKitUWXprCIcLoO;
@property(nonatomic, strong) NSArray *djNcilGtrZWHg;
@property(nonatomic, strong) NSMutableDictionary *nyHzOKJsSkwpZQaA;
@property(nonatomic, copy) NSString *kryGbEsQSoPXBJcekzA;
@property(nonatomic, strong) NSObject *mgKhYJFaSAGRd;
@property(nonatomic, strong) NSArray *quoSzaqFWAXkmUsieclf;
@property(nonatomic, strong) NSNumber *udmWqQlCpDnfPNwHdoFAkKYZXGg;
@property(nonatomic, strong) NSNumber *viTRkVzsWYtAMyQCPxeHjBEcZ;


/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
