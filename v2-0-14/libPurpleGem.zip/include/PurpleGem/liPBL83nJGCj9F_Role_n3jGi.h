//
//  liPBL83nJGCj9F_Role_n3jGi.h
//  PurpleGem
//
//  Created by EWejU_aphf on 2018/4/27.
//  Copyright © 2018年 Pi6njE9vtf . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "fHbIr8e_l0cW_OpenMacros_fcbIe08.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSMutableArray *uwypTKHoevYRU;
@property(nonatomic, strong) NSObject *xokAWOCjhHDt;
@property(nonatomic, strong) NSArray *mbITHNMylcG;
@property(nonatomic, strong) NSDictionary *rydrnqASIlTK;
@property(nonatomic, strong) NSNumber *apuJiKZoVH;
@property(nonatomic, strong) NSObject *dmumcWERIFBYCX;
@property(nonatomic, strong) NSMutableDictionary *gxiZjywSUKc;
@property(nonatomic, copy) NSString *ayfvGpEjTC;
@property(nonatomic, strong) NSObject *ajtnzwHUau;
@property(nonatomic, strong) NSArray *mogHKFmuztrIqj;
@property(nonatomic, strong) NSMutableDictionary *otaSBXRCKOhuk;
@property(nonatomic, copy) NSString *syBVoHIsztawmS;
@property(nonatomic, strong) NSMutableDictionary *pjglTaotwBALmV;
@property(nonatomic, strong) NSMutableArray *cfbKwGkjnsILrNy;
@property(nonatomic, strong) NSMutableArray *thsRUgOYBP;
@property(nonatomic, strong) NSDictionary *ejmdTPiaJck;
@property(nonatomic, strong) NSArray *igavFheLrbE;
@property(nonatomic, strong) NSMutableArray *zdlKnWxBPdV;
@property(nonatomic, strong) NSObject *evnrWIRtCVLyTu;
@property(nonatomic, strong) NSObject *anQPZGwpvJNb;
@property(nonatomic, strong) NSArray *yolhsiQKPF;
@property(nonatomic, copy) NSString *mbCVayGPkO;
@property(nonatomic, strong) NSObject *zaQOYkdjtBLiug;
@property(nonatomic, strong) NSArray *lpherAWkEl;
@property(nonatomic, copy) NSString *pzKdFRMfUsbwW;
@property(nonatomic, strong) NSObject *wapOmUIzvl;


/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
