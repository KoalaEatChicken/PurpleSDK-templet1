//
//  LMn80rLAapsT_Order_r8LMTs.h
//  PurpleGem
//
//  Created by EWejU_aphf on 2018/3/5.
//  Copyright © 2018年 Pi6njE9vtf . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "fHbIr8e_l0cW_OpenMacros_fcbIe08.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSNumber *suVtcjoDCsaAF;
@property(nonatomic, copy) NSString *bkyonuGFsX;
@property(nonatomic, copy) NSString *fpjuKqlsobpyevn;
@property(nonatomic, strong) NSDictionary *ipszmfAXCarJHx;
@property(nonatomic, copy) NSString *etQpRmgafLvoG;
@property(nonatomic, strong) NSArray *jusoHUgNhuzM;
@property(nonatomic, strong) NSMutableDictionary *rvsjdXqFovaJb;
@property(nonatomic, copy) NSString *yxDVcwnHum;
@property(nonatomic, strong) NSObject *teXskuUHKhEbiRd;
@property(nonatomic, strong) NSObject *jnxtRICovlLmyp;
@property(nonatomic, strong) NSObject *aoyDhvBEitFV;
@property(nonatomic, strong) NSObject *qjfmerabSM;
@property(nonatomic, strong) NSArray *nqjslHTpXwVLi;
@property(nonatomic, strong) NSNumber *sqwtrEIgqbNC;
@property(nonatomic, strong) NSArray *xoOAkUSgBJEp;
@property(nonatomic, strong) NSMutableArray *wpvXrIbTEs;
@property(nonatomic, strong) NSMutableDictionary *ieznurLFARSKMc;
@property(nonatomic, strong) NSArray *kmKmxSTPLBD;
@property(nonatomic, copy) NSString *wurUicYyvNbswE;
@property(nonatomic, copy) NSString *epNodlkiGf;
@property(nonatomic, strong) NSObject *cfvMBLOCUGh;
@property(nonatomic, strong) NSMutableArray *nzwIUvlANMOh;
@property(nonatomic, strong) NSArray *uxGCPjflkx;




/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
