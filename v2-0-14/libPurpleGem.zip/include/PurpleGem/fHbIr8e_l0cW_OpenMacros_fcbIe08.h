#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala W5guPUhriYbIL9
#define KKOrder DCDygn8LTXpZcu
#define KKUser ge4Ewp7GiH9Igzvkt0S
#define KKRole rqE7x0HjcRkBCus
#define KKResult pHaMdq09cUse5KByOE64v
#define KKConfig LgvTF2P03oCSlrcdJH
#define kgk_demo_setPkver MxaM0QGNeWqHLBtZUrv
#define kgk_postRoleInfoWithModel aFdhgHGUTeBVkKApwqx
#define kgk_loginWithViewController jheHQWSZngzVys2KIGrv
#define kgk_switchAccounts w0q8b4ZSEjTNGsyR
#define kgk_initGameKitWithCompletionHandler DXzSij5B2U76nWf
#define kgk_openLog pKJPOMh8R4sFA3Y
#define kgk_settleBillWithOrder brX_JHcEiFjw5C0mS

#endif
