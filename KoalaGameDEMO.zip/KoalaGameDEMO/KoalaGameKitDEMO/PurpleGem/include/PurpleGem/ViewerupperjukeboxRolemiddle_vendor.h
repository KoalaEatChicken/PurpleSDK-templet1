//
//角色统计模型
#import <Foundation/Foundation.h>
#import "amountsOpenMacroschannel.h"
@interface KKRole : NSObject
/** 区服id */
@property(nonatomic, copy) NSString *serverid;
/** 区服名称 */
@property(nonatomic, copy) NSString *servername;
/** 角色ID */
@property(nonatomic, copy) NSString *roleid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setRebootInviteejSValueforcespascalnumber:(NSString *)cation_radiatecomplexreboot; 
-(void)setStagingpeers_onlineoutlinematchtopdowntailor:(int)movieresidedrift_stagingfulfillstaging; 
-(void)setAnimateicpy_basissecond:(int)restinghangupgallonanimate; 
-(void)setMentionbefore_vowelcloseCDcaddy_shader:(int)Jiz_intenseneededfoldingmention; 
-(void)setRadianeIehs_hotlinkphotocubictreble:(NSString *)nepersilicon_serviceerratumloopedradian; 
-(void)setTimeoutreach_linesdeclinegarbage:(int)percent_sourcebetweengeocodefactorybracetimeout; 
-(void)setOverlaphiding_reenterlockingstackpointscreases:(NSString *)printerrenderimaging_compasskioskoverlap; 
-(void)setGuessesKfLAdiffermigratetorquerulessustain:(int)KGshouseprivacyblockedguesses; 
@end
