//
//  DkQ1NJ0I3UeZpi_User_13eN0Up.h
//  fjwdPurple
//
//  Created by ftqDaGJ9p on 2018/3/8.
//  Copyright © 2018年 zRXHrjPzyF . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "q9mEacRgK_OpenMacros_qKamc.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSDictionary *tnlCedZQVTXbo;
@property(nonatomic, strong) NSMutableDictionary *zdBIixXQUMZGAa;
@property(nonatomic, strong) NSArray *tbPzkpJXxMWBj;
@property(nonatomic, strong) NSArray *lcpVqftCNEB;
@property(nonatomic, copy) NSString *ryLVbfGpUrwc;
@property(nonatomic, copy) NSString *zynqJRcbSlVeO;
@property(nonatomic, strong) NSDictionary *affRKNhrDjGp;
@property(nonatomic, strong) NSDictionary *ishAqLZNMF;
@property(nonatomic, strong) NSDictionary *lbnhzKHdRkEaj;
@property(nonatomic, strong) NSMutableArray *uqlzvSsbYXpW;
@property(nonatomic, copy) NSString *feaCEtPWqV;
@property(nonatomic, strong) NSArray *urgrWYfAPMRj;
@property(nonatomic, strong) NSObject *wewyBReShqYKZ;
@property(nonatomic, strong) NSNumber *pkatUxdmEfnQLu;
@property(nonatomic, strong) NSMutableArray *jyLiwJCtdX;

/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
