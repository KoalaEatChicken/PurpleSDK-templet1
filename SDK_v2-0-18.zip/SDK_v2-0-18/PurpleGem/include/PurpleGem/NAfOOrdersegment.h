// 订单
#import <Foundation/Foundation.h>
#import "amountsOpenMacroschannel.h"
@interface KKOrder : NSObject
/** 商品名称  */
@property(nonatomic, copy) NSString *subject;
/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;
/** 订单号  */
@property(nonatomic, copy) NSString *billno;
/** 内购id  */
@property(nonatomic, copy) NSString *iapId;
/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;
/** 服务器id */
@property(nonatomic, copy) NSString *serverid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setBulletweightwatcheddippingvowel:(int)solely_clicksexecuteplaten_offerbullet; 
-(void)setNeededLabeledunseencomputeahead_prepare:(int)Workingdarkerdrawingneeded; 
-(void)setEntityOAknoceanimpulseblockerlayeraverage:(NSString *)Seldomsandboxpressesnucleuskillerlossystoredentity; 
-(void)setAtlasesCohereglitchdeliverbalanceonewaymacro:(int)settled_orientnamingatlases; 
@end
