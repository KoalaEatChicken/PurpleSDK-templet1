//
//  kMHoD58CTtUq_Result_58qTCkM.h
//  PurpleGem
//
//  Created by SMAvn50FVSIYaXcp on 2018/3/5.
//  Copyright © 2018年 Juv8BkRahY_W . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "zKcJpH0MObSWf_OpenMacros_ScOJb.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSMutableDictionary *yzLVIqpxTrDPnh;
@property(nonatomic, copy) NSString *exrTRGHOfLNotFmZsP;
@property(nonatomic, copy) NSString *cyQGxfTJVqPcpjASerzU;
@property(nonatomic, strong) NSNumber *mdUPKZNYyqjnpQRW;
@property(nonatomic, strong) NSNumber *dbAocvGqCDgExnrZYM;
@property(nonatomic, strong) NSNumber *gtsjAWklOpaLtFIRDiScJdmNoE;
@property(nonatomic, strong) NSNumber *vyqwvTrEYPfLGFJxcDhjgBds;
@property(nonatomic, strong) NSObject *twYUJDSZHtdzPcb;
@property(nonatomic, strong) NSMutableDictionary *ryjZfzCxmYUFqHAL;
@property(nonatomic, copy) NSString *knSfmKFscaQVUlndLpDArTqiu;
@property(nonatomic, strong) NSArray *dqJMwUnzSkdIPYpRro;
@property(nonatomic, strong) NSMutableArray *immENlIJrCGqS;
@property(nonatomic, strong) NSArray *ghloCGpjrziPFNZwfVsnTEI;
@property(nonatomic, strong) NSMutableDictionary *afWJjHhvmzFPpQACOYsqGobNl;
@property(nonatomic, strong) NSObject *ctTNgzcEsyKLSompQkA;
@property(nonatomic, strong) NSMutableArray *ejriXKNjhItPsuCfxOlBYAoRn;
@property(nonatomic, copy) NSString *czreSAcxipHdfOzngtyjLEbw;
@property(nonatomic, strong) NSArray *kzucVHeSEbpzCaomBFwYQUIx;
@property(nonatomic, strong) NSArray *kgbcjoaXFdKwigL;
@property(nonatomic, strong) NSNumber *zbMkapRPihqSnxBWQZ;
@property(nonatomic, strong) NSNumber *kyLPShGpxuUlVORFdQAoJNkTMvi;
@property(nonatomic, strong) NSDictionary *gmEZpdyiIJWkNjvOKeMaQ;
@property(nonatomic, strong) NSMutableArray *mlpYXsQacoyUmFtnNrBIg;
@property(nonatomic, strong) NSArray *qsVSQxDIyvEmMzKBLG;
@property(nonatomic, strong) NSDictionary *yiNaJbvAxlpPyTeiZzEsIfV;
@property(nonatomic, strong) NSNumber *odNZJmYPbhSjsVrECKX;
@property(nonatomic, strong) NSNumber *tiEONdFKmAMnrSscxylvuCQ;
@property(nonatomic, strong) NSArray *hwGhQDKbFpnYyUCw;




/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
