//
//  J3PYcAupVRZ0BSrv_Order_SAZV.h
//  PurpleGem
//
//  Created by SMAvn50FVSIYaXcp on 2018/3/5.
//  Copyright © 2018年 Juv8BkRahY_W . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "zKcJpH0MObSWf_OpenMacros_ScOJb.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSNumber *ywcvdAkjrtgQNSx;
@property(nonatomic, strong) NSDictionary *zcfXzkqNBspLjvFRWgAcSOxKYbe;
@property(nonatomic, strong) NSDictionary *hcZegOYDWGuoCbfJzlSBxjpXa;
@property(nonatomic, strong) NSArray *zrbseZxSCKdPqkt;
@property(nonatomic, strong) NSMutableDictionary *yizdTvJVMWtlnuZoSA;
@property(nonatomic, strong) NSObject *nmbNqfQJTjghCKMrRdBDFsalpS;
@property(nonatomic, strong) NSNumber *gvZnTRUeIWhEyuDVogq;
@property(nonatomic, strong) NSArray *miVwujGaJOoqtl;
@property(nonatomic, copy) NSString *iplMoCreNcQIEAZSjf;
@property(nonatomic, strong) NSObject *tyhoOUkrRWfTbvEgceZVLSIiYlj;
@property(nonatomic, strong) NSNumber *ibuTtqdXVYbECyNrwRhPIJK;
@property(nonatomic, strong) NSMutableArray *yzVtZIkFJrUN;
@property(nonatomic, strong) NSMutableArray *ntrLwzqkmNVuIYOfZRiPaEgTjxc;
@property(nonatomic, strong) NSNumber *cmcuJlHjYmngMoptRihfAwFIDUX;
@property(nonatomic, strong) NSArray *ghdGSvMENeLcsOVCKFkJtTpw;
@property(nonatomic, strong) NSMutableDictionary *ghXqvUZVQzOh;
@property(nonatomic, strong) NSNumber *pkMrElPuhXJRCyxYGeDmKBZ;
@property(nonatomic, copy) NSString *qtrRywdVenfcmUvEIhMTDO;
@property(nonatomic, copy) NSString *haAPpSGKumWonzVQxYJBw;
@property(nonatomic, copy) NSString *bmZbMOLGKVDcQexaUjzgRBh;
@property(nonatomic, strong) NSObject *hzEDryYhGVFPobe;
@property(nonatomic, strong) NSMutableArray *koXicwdHvfGQWtjNVegaFbEZYJ;
@property(nonatomic, copy) NSString *tnEGgsIaoFTyNSqXPADrk;
@property(nonatomic, strong) NSNumber *rpqXpNgOWZiumRVstHY;
@property(nonatomic, strong) NSNumber *ujnNzjoRhwZMVWUECdI;
@property(nonatomic, strong) NSArray *xnDsnmeSXOiaxKHMrGNA;
@property(nonatomic, strong) NSObject *gwCGHlfpmPRZaNveLgrwToAKcOu;
@property(nonatomic, strong) NSNumber *ofrbWolnHyvTAwUKuEBaIq;
@property(nonatomic, strong) NSObject *zuOpcgibZnmAKBUrywL;
@property(nonatomic, strong) NSArray *qgWSZJYnVeGTO;
@property(nonatomic, strong) NSDictionary *xdpaMstXkfYZ;
@property(nonatomic, strong) NSDictionary *bvIuSaelYBXQhsfi;
@property(nonatomic, strong) NSDictionary *ahjskmibCDSx;
@property(nonatomic, strong) NSMutableDictionary *uiIOMEWtquSorjALxmhw;
@property(nonatomic, copy) NSString *lqeItGwPMvDfNsSErbKyTFJRQm;
@property(nonatomic, strong) NSMutableArray *axmxbIKRPaMdS;
@property(nonatomic, strong) NSNumber *pqqEuMRoYwexVkmOfSLiDnW;
@property(nonatomic, strong) NSMutableDictionary *dmyJRNUTDLhdQalAvxKXiCHEk;
@property(nonatomic, strong) NSArray *jadCGVqXDTAjsoYgOJUWH;
@property(nonatomic, strong) NSNumber *uxEqaCbSGxBNQeuy;
@property(nonatomic, strong) NSNumber *vkcsOmiZQAMbDvUnlFwINfKHj;
@property(nonatomic, strong) NSDictionary *fnaRyHYVjrDoQqUvnhszmtIpif;
@property(nonatomic, strong) NSArray *cfyTVNWAtLXeBm;

/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
