#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKRole ldQO60Ssimh
#define Koala EEWhZFP23lVxU01
#define KKConfig F1p_JPGnmt9wYDOK7
#define KKResult VXKksOWIbFA86VD
#define KKOrder xsjLDznuYvxFhkaU_1l
#define KKUser WEsqDnOoUfFKZGg8hRJ_r
#define kgk_postRoleInfoWithModel PnoqCkJ9iLG4
#define kgk_switchAccounts neA2_NE8ovOTsrmZKS
#define kgk_settleBillWithOrder DWO8D3RC0QlX
#define kgk_loginWithViewController Yrj7nk2duvoVfbN
#define kgk_initGameKitWithCompletionHandler VDEqWg2GCkcr3lu1VPvw
#define kgk_openLog LdbK2lvy8ZG
#define kgk_demo_setPkver RzpxM9bVJgvytnqGU

#endif
