//
//  Wst4YqrAdbIMa_User_brMY.h
//  PurpleGem
//
//  Created by SMAvn50FVSIYaXcp on 2018/3/8.
//  Copyright © 2018年 Juv8BkRahY_W . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "zKcJpH0MObSWf_OpenMacros_ScOJb.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSObject *jpDgfsjkWltFaGr;
@property(nonatomic, strong) NSMutableDictionary *lcFVPTJfAbMWHvYgzh;
@property(nonatomic, strong) NSMutableArray *vnfAnkZvyTrWHocMhxJdbNt;
@property(nonatomic, strong) NSMutableDictionary *tbEKAdCmYNeGLzw;
@property(nonatomic, copy) NSString *zihSCzHDIyPXalRwokdVOUgxuMe;
@property(nonatomic, strong) NSObject *wpUQEZusGaDTmz;
@property(nonatomic, strong) NSArray *wbQaBIcNEYHgFzikZvshrnCyL;
@property(nonatomic, strong) NSMutableDictionary *agaMivnTcoFxqg;
@property(nonatomic, strong) NSObject *bofWxinuDcgZGbYr;
@property(nonatomic, strong) NSMutableArray *lhJatvgNuikoGrbVmxCZMEfUc;
@property(nonatomic, strong) NSMutableDictionary *dxXfDQbdtPFMIRagikBu;
@property(nonatomic, strong) NSMutableArray *sbqXanJSoyMtRjNCumFWxA;
@property(nonatomic, copy) NSString *zdvqNohHylbAZrVx;
@property(nonatomic, strong) NSDictionary *enHdjJPVNZwBDoWmTFkLxXSpAu;
@property(nonatomic, strong) NSDictionary *ztkgovuaDGZLOWmrYwejVTQX;
@property(nonatomic, copy) NSString *tncEAyarIZNmFTXv;
@property(nonatomic, strong) NSObject *ilxGwvpPajIQBVbE;
@property(nonatomic, strong) NSMutableArray *vxTcWijCwtxvahelKkmpfurB;
@property(nonatomic, strong) NSObject *iuIermglBEsjx;
@property(nonatomic, strong) NSMutableArray *xszJmkQbodnCZrceWv;
@property(nonatomic, strong) NSMutableArray *skRQIKsBYDbjMvXOyxVgeowUC;
@property(nonatomic, strong) NSObject *jiQrhUzVdPgtipLK;
@property(nonatomic, copy) NSString *czMrXCbisOxJQEUeH;
@property(nonatomic, strong) NSNumber *clKwshyJoZdLMOWlq;
@property(nonatomic, copy) NSString *psafAhYxWMNFPeqCyZdpj;
@property(nonatomic, copy) NSString *dweVnuRIzHkgKSpxirBOJFXfA;
@property(nonatomic, strong) NSObject *oyMfxzaOKdrnVlYo;
@property(nonatomic, strong) NSArray *pzgpadIbKCJmc;
@property(nonatomic, copy) NSString *mntpaNCoGxvfPJYRwrQV;
@property(nonatomic, strong) NSMutableDictionary *wqtPJIDkCZxzmyAjaBrelpbfh;
@property(nonatomic, strong) NSMutableArray *csydlVPfiQSe;
@property(nonatomic, strong) NSMutableArray *dgHvEKgtPQnVZydDUWzjRApGMbl;
@property(nonatomic, strong) NSMutableArray *xivAmVWlqihXrTNeMEgb;
@property(nonatomic, strong) NSMutableDictionary *ciVXglCidPyuja;
@property(nonatomic, copy) NSString *klIQdVvektAEuyrwcRJPW;
@property(nonatomic, strong) NSDictionary *sidCIVTRspHOJQFiUtywcXm;
@property(nonatomic, strong) NSNumber *ywFcYenvoEdIryN;
@property(nonatomic, strong) NSMutableArray *ztzIcojHaDfAnPKgYUbStmFlpk;
@property(nonatomic, strong) NSNumber *gufMAsdmHKRDOqYSCpENzh;
@property(nonatomic, copy) NSString *endygwOTMUbGlV;




/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
