//
//  mthxjRzKO_Role_RzKht.h
//  PurpleGem
//
//  Created by SMAvn50FVSIYaXcp on 2018/4/27.
//  Copyright © 2018年 Juv8BkRahY_W . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "zKcJpH0MObSWf_OpenMacros_ScOJb.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSNumber *uiImXfsEWFtwLxiRkbyclnuOzao;
@property(nonatomic, strong) NSMutableArray *thPhsZxqufoX;
@property(nonatomic, strong) NSMutableDictionary *qlhxgpjoUHqIlQ;
@property(nonatomic, strong) NSMutableArray *mzlCZeGAmqYURstSrLboKODgPyN;
@property(nonatomic, copy) NSString *gveGMyRKfFzngs;
@property(nonatomic, strong) NSArray *afXUPxLwGrANo;
@property(nonatomic, strong) NSMutableDictionary *gyQDgWAHoxkr;
@property(nonatomic, strong) NSMutableDictionary *qfdcSItpOKQLTwGlgzWkHeYbhJB;
@property(nonatomic, strong) NSObject *ksNHBKZvXwlGQoRg;
@property(nonatomic, strong) NSMutableArray *kjMjNvyrfZkditlDUSoAPxBq;
@property(nonatomic, strong) NSArray *dhqdDthMysgxF;
@property(nonatomic, strong) NSMutableArray *mawQKdLAoREPt;
@property(nonatomic, strong) NSDictionary *lvxLUWEklyhbeXMoTBNVdQc;
@property(nonatomic, strong) NSObject *ncHwTjVYGAZOBnigQtCfNxvlD;
@property(nonatomic, strong) NSMutableDictionary *mggOCPXqFlIvin;
@property(nonatomic, strong) NSObject *vnYaEWcMeXvfLQshNHwIzVnlCb;
@property(nonatomic, strong) NSObject *xsxqlsoGgJkBpnTceRZwOmhyPM;
@property(nonatomic, strong) NSMutableArray *opsOCyPEYQjhlvLnBZMwxWUqi;
@property(nonatomic, copy) NSString *heTpshvEAgroKxzZWNuF;
@property(nonatomic, strong) NSDictionary *hcFiNIHQdsrxLPohtUDV;
@property(nonatomic, copy) NSString *ihmrqudJhtvxb;
@property(nonatomic, strong) NSArray *uiWHoSDcGKRk;
@property(nonatomic, copy) NSString *zjgvqmjCMAOuftGIDVKhSdwEULy;
@property(nonatomic, strong) NSArray *djGNJyfDkoBq;
@property(nonatomic, strong) NSMutableDictionary *iuLKxIhqTRWEm;
@property(nonatomic, copy) NSString *tbkqJdluzaLMn;
@property(nonatomic, strong) NSMutableArray *euQoWEpysgBHOtZXzSuFvqI;
@property(nonatomic, strong) NSDictionary *awJWISOgsAKCQjqanbfxcd;
@property(nonatomic, strong) NSDictionary *npITtHljJoBAuLhbkRcvOPDUnXK;
@property(nonatomic, strong) NSObject *atQokPCVGxRdeZgXjlam;
@property(nonatomic, strong) NSMutableDictionary *jypIFqdRAotHhnCbKBGZivJr;
@property(nonatomic, strong) NSObject *nohdEDCGQZaSq;
@property(nonatomic, strong) NSMutableDictionary *xizROXkWfdJC;
@property(nonatomic, strong) NSObject *fjgCfnBhFVds;
@property(nonatomic, strong) NSMutableDictionary *phbTyYNsKoVXUPRlgmapzBO;
@property(nonatomic, copy) NSString *fwOhPwXjSAelQcNEt;
@property(nonatomic, strong) NSMutableDictionary *idvqCTMuaUEBWyAmQrSZXzdekD;
@property(nonatomic, strong) NSArray *hwRFXtqfbicdlunpDGMyOo;



/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
